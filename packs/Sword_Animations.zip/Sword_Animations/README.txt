SWORD ANIMATIONS - split from Rokoko Studio (Mocap) pack
46 separate clips, all on the Mixamo skeleton (mixamorig:*), 24 fps.

Folders / sources
  SwordFight/    from Combat/SwordFight_mixamo.fbx               (16 clips)
  SwordSamurai/  from RokokoTVContest/COMBAT/Sword_Samurai       (14 clips)
  SwordGeneric/  from RokokoTVContest/COMBAT/Sword_Generic       (16 clips)

File name tag (guessed from how much the body moves, NOT from what the move is)
  strong  = big, fast motion (best bet for actual attacks / combos)
  medium  = moderate motion
  light   = small motion (steps, guard changes, recoveries)
  walk    = mostly travelling across the floor

How the cutting was done
  - Auto-detected: cut at the pauses between moves, then trimmed standing-still
    frames off the start/end of each clip. Some clips may contain a combo of 2 swings,
    and a few may start or end a little early/late.
  - Frame 0 of every original is a T-pose, so it was removed.
  - Each clip's starting floor position is reset to the origin (hips X/Z). Height is untouched.
  - Animation data is otherwise untouched (verified against the originals).
  - clip_index.csv lists where each clip came from (seconds in the original file).
